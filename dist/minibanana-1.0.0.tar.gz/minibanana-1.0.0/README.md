# 🍌 minibanana

**minibanana** es un motor de videojuegos ultra simple hecho con Python + Tkinter.  
La idea es tener algo parecido a pygame, pero más pequeño y sencillo.
Nuestra opinión es que este motor no está
hecho para todos los desarrolladores, pero es
muy bueno para aprender a hacer juegos y también
hacer juegos simples.

## 🚀 Instalación